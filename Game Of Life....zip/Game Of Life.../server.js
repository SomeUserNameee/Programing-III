var express = require('express');
var app = express();
var server = require('http').Server(app);
var io = require('socket.io')(server);
var fs = require("fs");

function rand(arr) {
    return arr[Math.floor(Math.random() * arr.length)]
}

app.use(express.static("."));

app.get('/', function (req, res) {
    res.redirect('index.html');
});
server.listen(3000);

grassArr = [];
grassEaterArr = [];
predatorArr = [];
posionedGrassArr = [];
vochxarArr = [];
mardArr = [];
matrix = [];

var n = 50;

Grass = require("./Grass");
GrassEater = require("./GrassEater");
Predator = require("./Predator");
PosionedGrass = require("./PosionedGrass");
Vochxar = require("./Vochxar");
Mard = require("./Mard")

function rand(min, max) {
    return Math.random() * (max - min) + min;
}

for (let i = 0; i < n; i++) {
    matrix[i] = [];
    for (let j = 0; j < n; j++) {
        matrix[i][j] = Math.floor(rand(0,3))

    }
}

io.sockets.emit("send matrix", matrix)

function createObject() {
    for (var y = 0; y < matrix.length; y++) {
        for (var x = 0; x < matrix[y].length; x++) {
            if (matrix[y][x] == 1) {
                matrix[y][x] = 1
                grassArr.push(new Grass(x, y, 1))
            }
            else if (matrix[y][x] == 2) {
                matrix[y][x] = 2
                grassEaterArr.push(new GrassEater(x, y, 2))
            }
            else if (matrix[y][x] == 3) {
                matrix[y][x] = 3
                predatorArr.push(new Predator(x, y, 3))
            }
            else if (matrix[y][x] == 4) {
                matrix[y][x] = 4
                posionedGrassArr.push(new PosionedGrass(x, y, 4))
            }
            else if (matrix[y][x] == 5) {
                matrix[y][x] = 5
                vochxarArr.push(new Vochxar(x, y, 5))
            }
            else if (matrix[y][x] == 6) {
                matrix[y][x] = 6
                mardArr.push(new Mard(x, y, 6))
            }
        }
    }
    io.sockets.emit('send matrix', matrix)
}

function game() {
    for (let i in grassArr) {
        grassArr[i].mul();
    }
    for (let i in grassEaterArr) {
        grassEaterArr[i].eat();
    }
    for (let i in predatorArr) {
        predatorArr[i].eat();
    }
    for (let i in posionedGrassArr) {
        posionedGrassArr[i].mul();
    }
    for (let i in vochxarArr) {
        vochxarArr[i].bomb();
    }
    for(let i in mardArr){
mardArr[i].checkKey()
    }
    io.sockets.emit("send matrix", matrix);
}

setInterval(game, 500)


function kill() {
    grassArr = [];
    grassEaterArr = [];
    predatorArr = [];
    PosionedGrassArr = [];
    vochxarArr = [];
    MardArr = [];
    for (var y = 0; y < matrix.length; y++) {
        for (var x = 0; x < matrix[y].length; x++) {
            matrix[y][x] = 0;
        }
    }
    io.sockets.emit("send matrix", matrix);
}


function addGrass() {
    for (var i = 0; i < 7; i++) {
        var x = Math.floor(Math.random() * matrix[0].length)
        var y = Math.floor(Math.random() * matrix.length)
        if (matrix[y][x] == 0) {
            matrix[y][x] = 1
            var gr = new Grass(x, y, 1)
            grassArr.push(gr)
        }
    }
    io.sockets.emit("send matrix", matrix);
}
function addGrassEater() {
    for (var i = 0; i < 7; i++) {
        var x = Math.floor(Math.random() * matrix[0].length)
        var y = Math.floor(Math.random() * matrix.length)
        if (matrix[y][x] == 0) {
            matrix[y][x] = 2
            var gre = new GrassEater(x, y, 2)
            grassEaterArr.push(gre)
        }
    }
    io.sockets.emit("send matrix", matrix);
}
function addPredator() {
    for (var i = 0; i < 7; i++) {
        var x = Math.floor(Math.random() * matrix[0].length)
        var y = Math.floor(Math.random() * matrix.length)
        if (matrix[y][x] == 0) {
            matrix[y][x] = 3
            var pred = new Predator(x, y, 3)
            predatorArr.push(pred)
        }
    }
    io.sockets.emit("send matrix", matrix);
}
function addPosionedGrass() {
    for (var i = 0; i < 7; i++) {
        var x = Math.floor(Math.random() * matrix[0].length)
        var y = Math.floor(Math.random() * matrix.length)
        if (matrix[y][x] == 0) {
            matrix[y][x] = 4
            var posioned = new PosionedGrass(x,y,4)
            PosionedGrassArr.push(posioned)
        }
    }
    io.sockets.emit("send matrix", matrix);
}
function addVochxar() {
    for (var i = 0; i < 7; i++) {
        var x = Math.floor(Math.random() * matrix[0].length)
        var y = Math.floor(Math.random() * matrix.length)
        if (matrix[y][x] == 0) {
            matrix[y][x] = 5
            var voc = new Vochxar(x,y,5)
            vochxarArr.push()
        }
    }
    io.sockets.emit("send matrix", matrix);
}


io.on('connection', function (socket) {
    createObject();
    socket.on("kill", kill);
    socket.on("Add Grass", addGrass);
    socket.on("Add GrassEater", addGrassEater);
});


var statistics = {};

setInterval(function () {
    statistics.grass = grassArr.length;
    statistics.grassEater = grassEaterArr.length;
    fs.writeFile("statistics.json", JSON.stringify(statistics), function () {
        console.log("send")
    })
}, 1000)








